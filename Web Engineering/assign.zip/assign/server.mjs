import express from 'express'
import session from 'express-session'
import cookieparser from "cookie-parser";
import cors from "cors";
const app = express()
app.use(cookieparser())
app.use(cors());
let shared_counter = 0;
let userCounters = {}
app.get('/page1', function (req, res) {
    shared_counter++
    return res.send(
      `
      <form method="get">
      <p>Shared Value:${shared_counter}</p>
      <button type="submit">Update</button>
      </form>
      `
    )
});

app.get('/page2', function (req, res) {
  let ID = req?.cookies?.ID || Math.floor(Math.random()*10000).toString()
  console.log("User ID",ID)
  let my_counter = userCounters[ID] || 0
  console.log(userCounters)
  userCounters[ID] = (parseInt(my_counter) + 1).toString()
  res.cookie('Id', ID);
  return res.json(
    {my_counter}
  )
});
app.get('/page3', (req, res) => {
    var expires = req.cookies.pageExpiry;
    if (!expires || expires < new Date()) {
        var date = new Date();
        date.setSeconds(date.getSeconds() + 5);
        res.cookie('pageExpiry', date);
        res.send(`<p>This page will expire at ${ date }</p>`);
    } else {
        res.send("Page expired");
    }
  });

app.listen(5000, function () {
    console.log("Listening on port 5000 ...");
});