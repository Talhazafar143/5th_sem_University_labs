const express = require("express");
const cookieParser = require("cookie-parser");

const app = express();
app.use(cookieParser());
let sharedCounter = 0;

app.get("/page1", (req, res) => {
  res.sendFile(__dirname + "/page1.html");
});

app.get("/page2", (req, res) => {
  let privateCounter = 0;
  if (req.cookies.privateCounter) {
    privateCounter = req.cookies.privateCounter;
  }
  res.sendFile(__dirname + "/page2.html");
});

app.get("/page3", (req, res) => {
  res.sendFile(__dirname + "/page3.html");
});

app.get("/increase_shared", (req, res) => {
  sharedCounter++;
  res.send({
    sharedCounter
  });
});

app.get("/increase_private", (req, res) => {
  let privateCounter = 0;
  if (req.cookies.privateCounter) {
    privateCounter = req.cookies.privateCounter;
  }
  privateCounter++;
  res.cookie("privateCounter", privateCounter);
  res.send({
    privateCounter
  });
});

app.listen(80, function () {
  console.log("Listening on port 80 ...");
});